package com.iit.TicketSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
