package lk.iit.TicketSystem.util.enums;

public enum TicketType {

    SILVER, GOLD, PLATINUM, DIAMOND

}
