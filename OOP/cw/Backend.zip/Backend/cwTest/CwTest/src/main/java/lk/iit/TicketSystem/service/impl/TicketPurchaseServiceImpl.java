package lk.iit.TicketSystem.service.impl;

import lk.iit.TicketSystem.service.TicketPurchaseService;

public class TicketPurchaseServiceImpl implements TicketPurchaseService {
}
