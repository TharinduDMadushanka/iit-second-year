package lk.iit.TicketSystem.service;

import org.springframework.stereotype.Service;

@Service
public interface TicketPurchaseService {
}
